<?php
// Koneksi database

    $hostname ='localhost';
    $username = 'root';
    $password = '';
    $db = 'latihanujk';

    $conn = mysqli_connect($hostname, $username, $password, $db);

?>